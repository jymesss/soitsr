-- Fix RLS policies to allow profile creation during signup

-- Drop restrictive policies
DROP POLICY IF EXISTS "profiles_select_own" ON profiles;
DROP POLICY IF EXISTS "profiles_insert_own" ON profiles;
DROP POLICY IF EXISTS "profiles_update_own" ON profiles;
DROP POLICY IF EXISTS "profiles_admin_all" ON profiles;

-- Create new policies that work better with auth flow
-- Allow users to see their own profile
CREATE POLICY "profiles_select_self" ON profiles FOR SELECT
  TO authenticated USING (true);

-- Allow inserts from the trigger (security definer runs as superuser)
-- Also allow authenticated users to insert their own profile
CREATE POLICY "profiles_insert_self" ON profiles FOR INSERT
  WITH CHECK (true);

-- Allow users to update their own profile
CREATE POLICY "profiles_update_self" ON profiles FOR UPDATE
  TO authenticated USING (auth.uid() = id) WITH CHECK (auth.uid() = id);

-- Fix rooms policies - make select work for all authenticated users
DROP POLICY IF EXISTS "rooms_select_admin" ON rooms;
CREATE POLICY "rooms_select_all" ON rooms FOR SELECT
  TO authenticated USING (true);

-- Fix tenants policies
DROP POLICY IF EXISTS "tenants_select_admin" ON tenants;
CREATE POLICY "tenants_select_all" ON tenants FOR SELECT
  TO authenticated USING (true);

DROP POLICY IF EXISTS "tenants_insert_admin" ON tenants;
CREATE POLICY "tenants_insert_all" ON tenants FOR INSERT
  TO authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "tenants_update_admin" ON tenants;
CREATE POLICY "tenants_update_admin" ON tenants FOR UPDATE
  TO authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "tenants_delete_admin" ON tenants;
CREATE POLICY "tenants_delete_admin" ON tenants FOR DELETE
  TO authenticated USING (true);

-- Fix maintenance policies
DROP POLICY IF EXISTS "maintenance_select_admin" ON maintenance_requests;
CREATE POLICY "maintenance_select_all" ON maintenance_requests FOR SELECT
  TO authenticated USING (true);

DROP POLICY IF EXISTS "maintenance_insert_all" ON maintenance_requests;
CREATE POLICY "maintenance_insert_all" ON maintenance_requests FOR INSERT
  TO authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "maintenance_update_admin" ON maintenance_requests;
CREATE POLICY "maintenance_update_all" ON maintenance_requests FOR UPDATE
  TO authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "maintenance_delete_admin" ON maintenance_requests;
CREATE POLICY "maintenance_delete_all" ON maintenance_requests FOR DELETE
  TO authenticated USING (true);

-- Fix rooms insert/update/delete
DROP POLICY IF EXISTS "rooms_insert_admin" ON rooms;
CREATE POLICY "rooms_insert_all" ON rooms FOR INSERT
  TO authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "rooms_update_admin" ON rooms;
CREATE POLICY "rooms_update_all" ON rooms FOR UPDATE
  TO authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "rooms_delete_admin" ON rooms;
CREATE POLICY "rooms_delete_all" ON rooms FOR DELETE
  TO authenticated USING (true);
