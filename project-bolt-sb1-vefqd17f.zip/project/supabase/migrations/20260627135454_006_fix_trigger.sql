-- Fix the trigger to properly handle new user signup
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
DROP FUNCTION IF EXISTS handle_new_user_with_role();

-- Create improved function that handles role assignment
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  user_role TEXT := 'tenant';
  user_name TEXT;
BEGIN
  -- Get user's full name from metadata
  user_name := COALESCE(NEW.raw_user_meta_data->>'full_name', NEW.email);
  
  -- Check for explicit role in metadata (from signup)
  IF NEW.raw_user_meta_data->>'role' = 'admin' THEN
    user_role := 'admin';
  -- Check if user name matches admin patterns
  ELSIF user_name ILIKE '%guevarra%' OR 
       user_name ILIKE '%alzona%' OR 
       user_name ILIKE '%bernabeo%' THEN
    user_role := 'admin';
  END IF;
  
  -- Insert into profiles
  INSERT INTO public.profiles (id, email, full_name, role)
  VALUES (NEW.id, NEW.email, user_name, user_role);
  
  RETURN NEW;
END;
$$;

-- Create the trigger
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW
  EXECUTE FUNCTION public.handle_new_user();
