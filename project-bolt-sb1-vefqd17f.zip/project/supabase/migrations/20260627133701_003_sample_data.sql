-- Insert sample tenants
INSERT INTO tenants (first_name, last_name, email, phone, emergency_contact, move_in_date, status)
VALUES
  ('John', 'Dela Cruz', 'john@email.com', '+639171234567', 'Parent Dela Cruz +639171234568', '2025-07-01'::date, 'active'),
  ('Jane', 'Reyes', 'jane@email.com', '+639189876543', 'Parent Reyes +639189876544', '2025-08-15'::date, 'active'),
  ('Pedro', 'Santos', 'pedro@email.com', '+639281234567', 'Parent Santos +639281234568', '2025-09-01'::date, 'active'),
  ('Maria', 'Garcia', 'maria@email.com', '+639329876543', 'Parent Garcia +639329876544', '2025-10-01'::date, 'active')
ON CONFLICT DO NOTHING;

-- Update some rooms to occupied
UPDATE rooms SET status = 'occupied' WHERE room_number IN ('101', '102') AND status = 'available';

-- Assign some tenants to rooms
UPDATE tenants SET room_id = (SELECT id FROM rooms WHERE room_number = '101') WHERE first_name = 'John' AND last_name = 'Dela Cruz';
UPDATE tenants SET room_id = (SELECT id FROM rooms WHERE room_number = '102') WHERE first_name = 'Jane' AND last_name = 'Reyes';

-- Insert sample maintenance requests
INSERT INTO maintenance_requests (room_id, issue_description, status, reported_date)
VALUES
  ((SELECT id FROM rooms WHERE room_number = '101'), 'Broken faucet in bathroom', 'pending', '2026-06-20'::date),
  ((SELECT id FROM rooms WHERE room_number = '201'), 'AC not working properly', 'in_progress', '2026-06-22'::date),
  ((SELECT id FROM rooms WHERE room_number = '301'), 'Loose door lock', 'resolved', '2026-06-15'::date)
ON CONFLICT DO NOTHING;
