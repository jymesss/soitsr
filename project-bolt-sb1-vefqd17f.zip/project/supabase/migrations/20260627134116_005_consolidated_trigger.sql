-- Combine triggers into one that handles both profile creation AND admin role assignment

-- Drop all existing triggers
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
DROP TRIGGER IF EXISTS on_profile_created ON profiles;
DROP FUNCTION IF EXISTS handle_new_user();
DROP FUNCTION IF EXISTS assign_admin_role();

-- Create a single combined function
CREATE OR REPLACE FUNCTION handle_new_user_with_role()
RETURNS TRIGGER AS $$
DECLARE
  user_role TEXT := 'tenant';
  user_name TEXT;
BEGIN
  -- Get user's full name from metadata
  user_name := COALESCE(NEW.raw_user_meta_data->>'full_name', NEW.email);
  
  -- Check if user should be admin based on name
  IF user_name ILIKE '%guevarra%' OR 
     user_name ILIKE '%alzona%' OR 
     user_name ILIKE '%bernabeo%' THEN
    user_role := 'admin';
  END IF;
  
  -- Also check for explicit role in metadata
  IF NEW.raw_user_meta_data->>'role' = 'admin' THEN
    user_role := 'admin';
  END IF;
  
  -- Create profile
  INSERT INTO profiles (id, email, full_name, role)
  VALUES (NEW.id, NEW.email, user_name, user_role);
  
  RETURN NEW;
EXCEPTION WHEN OTHERS THEN
  -- Log error but don't fail the user creation
  RAISE WARNING 'Failed to create profile for user %: %', NEW.id, SQLERRM;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create the trigger
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION handle_new_user_with_role();
