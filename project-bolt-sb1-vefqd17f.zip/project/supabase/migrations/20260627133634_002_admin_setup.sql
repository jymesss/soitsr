-- Create a function to check if a user should be an admin
-- Admins: Guevarra, Alzona, Bernabeo

-- Update existing profiles to admin if their name matches admin list
UPDATE profiles 
SET role = 'admin' 
WHERE 
  full_name ILIKE '%guevarra%' OR
  full_name ILIKE '%alzona%' OR
  full_name ILIKE '%bernabeo%';

-- Create trigger to auto-assign admin role for specific names
CREATE OR REPLACE FUNCTION assign_admin_role()
RETURNS TRIGGER AS $$
BEGIN
  IF NEW.full_name ILIKE '%guevarra%' OR 
     NEW.full_name ILIKE '%alzona%' OR 
     NEW.full_name ILIKE '%bernabeo%' THEN
    NEW.role := 'admin';
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

CREATE OR REPLACE TRIGGER on_profile_created
  BEFORE INSERT ON profiles
  FOR EACH ROW
  EXECUTE FUNCTION assign_admin_role();
