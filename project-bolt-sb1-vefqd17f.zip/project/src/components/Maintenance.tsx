import { useEffect, useState } from 'react';
import { supabase, MaintenanceRequest, Room } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import { Plus, Edit2, Wrench, AlertCircle, CheckCircle, Clock, X, Shield, User } from 'lucide-react';

export function Maintenance() {
  const { isAdmin, user, profile } = useAuth();
  const [requests, setRequests] = useState<(MaintenanceRequest & { room: Room | null })[]>([]);
  const [rooms, setRooms] = useState<Room[]>([]);
  const [loading, setLoading] = useState(true);
  const [modalOpen, setModalOpen] = useState(false);
  const [editingRequest, setEditingRequest] = useState<MaintenanceRequest | null>(null);
  const [formData, setFormData] = useState({
    room_id: '',
    issue_description: '',
    status: 'pending' as 'pending' | 'in_progress' | 'resolved',
    reported_date: new Date().toISOString().split('T')[0],
  });

  useEffect(() => {
    fetchData();
  }, [isAdmin, user]);

  async function fetchData() {
    setLoading(true);
    let query = supabase
      .from('maintenance_requests')
      .select('*, room:rooms(*)')
      .order('created_at', { ascending: false });

    // Tenants only see their own room's requests
    if (!isAdmin && user) {
      const { data: tenantData } = await supabase
        .from('tenants')
        .select('room_id')
        .eq('user_id', user.id)
        .single();

      if (tenantData?.room_id) {
        query = query.eq('room_id', tenantData.room_id);
      } else {
        // If tenant has no room assigned, show nothing
        setRequests([]);
        setLoading(false);
        return;
      }
    }

    const { data: requestsData } = await query;
    setRequests((requestsData as (MaintenanceRequest & { room: Room | null })[]) || []);

    // For admin, get all rooms. For tenant, get all rooms for submission
    const { data: roomsData } = await supabase.from('rooms').select('*').order('room_number');
    setRooms(roomsData || []);
    setLoading(false);
  }

  function openModal(request?: MaintenanceRequest) {
    if (request && !isAdmin) return; // Tenants can't edit
    if (request) {
      setEditingRequest(request);
      setFormData({
        room_id: request.room_id,
        issue_description: request.issue_description,
        status: request.status,
        reported_date: request.reported_date,
      });
    } else {
      setEditingRequest(null);
      setFormData({
        room_id: '',
        issue_description: '',
        status: 'pending',
        reported_date: new Date().toISOString().split('T')[0],
      });
    }
    setModalOpen(true);
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    const data = {
      ...formData,
      resolved_date: formData.status === 'resolved' ? new Date().toISOString().split('T')[0] : null,
    };

    if (editingRequest && isAdmin) {
      await supabase
        .from('maintenance_requests')
        .update(data)
        .eq('id', editingRequest.id);
    } else {
      await supabase.from('maintenance_requests').insert(data);
    }
    setModalOpen(false);
    fetchData();
  }

  const statusConfig = {
    pending: { icon: Clock, color: 'amber', label: 'Pending', bg: 'bg-amber-50', text: 'text-amber-600' },
    in_progress: { icon: Wrench, color: 'blue', label: 'In Progress', bg: 'bg-blue-50', text: 'text-blue-600' },
    resolved: { icon: CheckCircle, color: 'emerald', label: 'Resolved', bg: 'bg-emerald-50', text: 'text-emerald-600' },
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <div className="w-8 h-8 border-4 border-blue-600 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">
            {isAdmin ? 'Maintenance Management' : 'My Maintenance Requests'}
          </h1>
          <p className="text-slate-500 mt-1">
            {isAdmin
              ? 'Track, update, and resolve all maintenance requests'
              : 'Submit and track maintenance requests for your room'}
          </p>
        </div>
        <button
          onClick={() => openModal()}
          className="flex items-center gap-2 px-5 py-2.5 bg-blue-600 text-white rounded-xl font-semibold hover:bg-blue-700 transition-colors shadow-lg shadow-blue-500/20"
        >
          <Plus className="w-5 h-5" />
          {isAdmin ? 'New Request' : 'Submit Request'}
        </button>
      </div>

      {/* Admin Info Banner */}
      {isAdmin && (
        <div className="bg-blue-50 border border-blue-200 rounded-xl p-4 flex items-center gap-3">
          <Shield className="w-6 h-6 text-blue-600 flex-shrink-0" />
          <div>
            <p className="font-semibold text-blue-900">Admin Access - Full Control</p>
            <p className="text-sm text-blue-700">You can update status, mark as resolved, and manage all maintenance requests.</p>
          </div>
        </div>
      )}

      {/* Tenant Info Banner */}
      {!isAdmin && (
        <div className="bg-amber-50 border border-amber-200 rounded-xl p-4 flex items-center gap-3">
          <User className="w-6 h-6 text-amber-600 flex-shrink-0" />
          <div>
            <p className="font-semibold text-amber-900">Tenant Access - Submit Requests</p>
            <p className="text-sm text-amber-700">You can submit maintenance requests for your assigned room. Admin will handle the resolution.</p>
          </div>
        </div>
      )}

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {(Object.keys(statusConfig) as Array<keyof typeof statusConfig>).map((status) => {
          const config = statusConfig[status];
          const Icon = config.icon;
          const count = requests.filter((r) => r.status === status).length;
          return (
            <div
              key={status}
              className={`bg-white rounded-2xl shadow-sm border border-slate-100 p-5 flex items-center gap-4`}
            >
              <div className={`w-12 h-12 rounded-xl ${config.bg} flex items-center justify-center`}>
                <Icon className={`w-6 h-6 ${config.text}`} />
              </div>
              <div>
                <div className="text-3xl font-bold text-slate-900">{count}</div>
                <div className="text-sm text-slate-500">{config.label}</div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Requests List */}
      <div className="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-slate-50 border-b border-slate-100">
              <tr>
                <th className="text-left text-xs font-semibold text-slate-500 uppercase tracking-wider px-6 py-4">Room</th>
                <th className="text-left text-xs font-semibold text-slate-500 uppercase tracking-wider px-6 py-4">Issue Description</th>
                <th className="text-left text-xs font-semibold text-slate-500 uppercase tracking-wider px-6 py-4">Status</th>
                <th className="text-left text-xs font-semibold text-slate-500 uppercase tracking-wider px-6 py-4">Reported</th>
                {isAdmin && (
                  <th className="text-left text-xs font-semibold text-slate-500 uppercase tracking-wider px-6 py-4">Resolved</th>
                )}
                <th className="text-left text-xs font-semibold text-slate-500 uppercase tracking-wider px-6 py-4">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {requests.map((request) => {
                const config = statusConfig[request.status];
                const StatusIcon = config.icon;
                return (
                  <tr key={request.id} className="hover:bg-slate-50 transition-colors">
                    <td className="px-6 py-4">
                      <span className="px-3 py-1.5 bg-slate-100 text-slate-700 rounded-lg text-sm font-semibold">
                        {request.room?.room_number || 'N/A'}
                      </span>
                    </td>
                    <td className="px-6 py-4">
                      <div className="max-w-xs">
                        <p className="text-slate-900 line-clamp-2">{request.issue_description}</p>
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <span className={`inline-flex items-center gap-2 px-3 py-1.5 rounded-full text-sm font-semibold ${
                        config.color === 'amber' ? 'bg-amber-100 text-amber-700' :
                        config.color === 'blue' ? 'bg-blue-100 text-blue-700' :
                        'bg-emerald-100 text-emerald-700'
                      }`}>
                        <StatusIcon className="w-4 h-4" />
                        {config.label}
                      </span>
                    </td>
                    <td className="px-6 py-4 text-slate-600">
                      {new Date(request.reported_date).toLocaleDateString()}
                    </td>
                    {isAdmin && (
                      <td className="px-6 py-4 text-slate-600">
                        {request.resolved_date ? new Date(request.resolved_date).toLocaleDateString() : '-'}
                      </td>
                    )}
                    <td className="px-6 py-4">
                      {isAdmin && (
                        <button
                          onClick={() => openModal(request)}
                          className="p-2 text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
                          title="Edit Request"
                        >
                          <Edit2 className="w-4 h-4" />
                        </button>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        {requests.length === 0 && (
          <div className="py-12 text-center">
            <AlertCircle className="w-12 h-12 mx-auto mb-3 text-slate-300" />
            <p className="text-slate-500">
              {isAdmin ? 'No maintenance requests found.' : 'You have no maintenance requests yet. Submit one above.'}
            </p>
          </div>
        )}
      </div>

      {/* Modal */}
      {modalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm">
          <div className="w-full max-w-md bg-white rounded-2xl shadow-2xl overflow-hidden max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100 sticky top-0 bg-white">
              <h2 className="text-lg font-semibold text-slate-900">
                {editingRequest ? (isAdmin ? 'Edit Request' : 'Request Details') : 'New Maintenance Request'}
              </h2>
              <button
                onClick={() => setModalOpen(false)}
                className="p-2 text-slate-400 hover:text-slate-600 hover:bg-slate-100 rounded-lg transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="p-6 space-y-4">
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1.5">
                  Room *
                </label>
                {editingRequest && isAdmin ? (
                  <div className="px-4 py-2.5 bg-slate-100 rounded-xl text-slate-600">
                    Room {requests.find((r) => r.id === editingRequest.id)?.room?.room_number || 'N/A'}
                  </div>
                ) : (
                  <select
                    value={formData.room_id}
                    onChange={(e) => setFormData({ ...formData, room_id: e.target.value })}
                    required
                    className="w-full px-4 py-2.5 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
                  >
                    <option value="">-- Select Room --</option>
                    {rooms.map((room) => (
                      <option key={room.id} value={room.id}>
                        Room {room.room_number} (Floor {room.floor}) - {room.status}
                      </option>
                    ))}
                  </select>
                )}
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1.5">
                  Issue Description *
                </label>
                <textarea
                  value={formData.issue_description}
                  onChange={(e) => setFormData({ ...formData, issue_description: e.target.value })}
                  required
                  rows={4}
                  className="w-full px-4 py-2.5 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all resize-none"
                  placeholder="Describe the maintenance issue..."
                />
              </div>

              {isAdmin && (
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1.5">
                    Update Status
                  </label>
                  <select
                    value={formData.status}
                    onChange={(e) => setFormData({ ...formData, status: e.target.value as typeof formData.status })}
                    className="w-full px-4 py-2.5 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
                  >
                    <option value="pending">Pending</option>
                    <option value="in_progress">In Progress</option>
                    <option value="resolved">Resolved</option>
                  </select>
                </div>
              )}

              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1.5">
                  Reported Date
                </label>
                <input
                  type="date"
                  value={formData.reported_date}
                  onChange={(e) => setFormData({ ...formData, reported_date: e.target.value })}
                  className="w-full px-4 py-2.5 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
                />
              </div>

              <button
                type="submit"
                className="w-full py-3 bg-blue-600 text-white font-semibold rounded-xl hover:bg-blue-700 transition-colors shadow-lg shadow-blue-500/20"
              >
                {editingRequest ? 'Save Changes' : 'Submit Request'}
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
