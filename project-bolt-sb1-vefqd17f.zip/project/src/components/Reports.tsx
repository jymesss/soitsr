import { useEffect, useState } from 'react';
import { supabase, Room, Tenant, MaintenanceRequest } from '../lib/supabase';
import { FileBarChart, Users, DoorOpen, Wrench, TrendingUp, Download, Calendar } from 'lucide-react';

export function Reports() {
  const [stats, setStats] = useState({
    totalRooms: 0,
    occupiedRooms: 0,
    availableRooms: 0,
    maintenanceRooms: 0,
    totalTenants: 0,
    activeTenants: 0,
    totalRequests: 0,
    pendingRequests: 0,
    resolvedRequests: 0,
    occupancyRate: 0,
  });
  const [rooms, setRooms] = useState<Room[]>([]);
  const [tenants, setTenants] = useState<Tenant[]>([]);
  const [requests, setRequests] = useState<MaintenanceRequest[]>([]);
  const [loading, setLoading] = useState(true);
  const [dateRange, setDateRange] = useState({
    start: new Date(new Date().setMonth(new Date().getMonth() - 1)).toISOString().split('T')[0],
    end: new Date().toISOString().split('T')[0],
  });

  useEffect(() => {
    fetchReportData();
  }, []);

  async function fetchReportData() {
    const [roomsRes, tenantsRes, requestsRes] = await Promise.all([
      supabase.from('rooms').select('*'),
      supabase.from('tenants').select('*'),
      supabase.from('maintenance_requests').select('*'),
    ]);

    const roomsData = roomsRes.data || [];
    const tenantsData = tenantsRes.data || [];
    const requestsData = requestsRes.data || [];

    setRooms(roomsData);
    setTenants(tenantsData);
    setRequests(requestsData);

    const occupied = roomsData.filter((r) => r.status === 'occupied').length;
    const available = roomsData.filter((r) => r.status === 'available').length;
    const maintenance = roomsData.filter((r) => r.status === 'maintenance').length;
    const active = tenantsData.filter((t) => t.status === 'active').length;
    const pending = requestsData.filter((r) => r.status === 'pending').length;
    const resolved = requestsData.filter((r) => r.status === 'resolved').length;

    setStats({
      totalRooms: roomsData.length,
      occupiedRooms: occupied,
      availableRooms: available,
      maintenanceRooms: maintenance,
      totalTenants: tenantsData.length,
      activeTenants: active,
      totalRequests: requestsData.length,
      pendingRequests: pending,
      resolvedRequests: resolved,
      occupancyRate: roomsData.length > 0 ? Math.round((occupied / roomsData.length) * 100) : 0,
    });

    setLoading(false);
  }

  function generateCSV(data: object[], filename: string) {
    if (data.length === 0) return;
    const headers = Object.keys(data[0]);
    const csvContent = [
      headers.join(','),
      ...data.map((row) =>
        headers.map((h) => JSON.stringify((row as Record<string, unknown>)[h] ?? '')).join(',')
      ),
    ].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${filename}_${new Date().toISOString().split('T')[0]}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <div className="w-8 h-8 border-4 border-blue-600 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Reports & Analytics</h1>
          <p className="text-slate-500 mt-1">Generate comprehensive reports for dormitory operations</p>
        </div>
      </div>

      {/* Date Range Filter */}
      <div className="bg-white rounded-2xl shadow-sm border border-slate-100 p-4">
        <div className="flex items-center gap-4 flex-wrap">
          <Calendar className="w-5 h-5 text-slate-400" />
          <div className="flex items-center gap-2">
            <label className="text-sm font-medium text-slate-700">From:</label>
            <input
              type="date"
              value={dateRange.start}
              onChange={(e) => setDateRange({ ...dateRange, start: e.target.value })}
              className="px-3 py-2 border border-slate-200 rounded-lg text-sm"
            />
          </div>
          <div className="flex items-center gap-2">
            <label className="text-sm font-medium text-slate-700">To:</label>
            <input
              type="date"
              value={dateRange.end}
              onChange={(e) => setDateRange({ ...dateRange, end: e.target.value })}
              className="px-3 py-2 border border-slate-200 rounded-lg text-sm"
            />
          </div>
        </div>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-gradient-to-br from-blue-500 to-blue-600 rounded-2xl p-6 text-white">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-blue-100 text-sm font-medium">Occupancy Rate</p>
              <p className="text-4xl font-bold mt-1">{stats.occupancyRate}%</p>
            </div>
            <TrendingUp className="w-10 h-10 text-blue-200" />
          </div>
          <p className="text-blue-200 text-sm mt-3">{stats.occupiedRooms} of {stats.totalRooms} rooms occupied</p>
        </div>

        <div className="bg-gradient-to-br from-emerald-500 to-emerald-600 rounded-2xl p-6 text-white">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-emerald-100 text-sm font-medium">Active Tenants</p>
              <p className="text-4xl font-bold mt-1">{stats.activeTenants}</p>
            </div>
            <Users className="w-10 h-10 text-emerald-200" />
          </div>
          <p className="text-emerald-200 text-sm mt-3">{stats.totalTenants} total registered</p>
        </div>

        <div className="bg-gradient-to-br from-amber-500 to-amber-600 rounded-2xl p-6 text-white">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-amber-100 text-sm font-medium">Pending Requests</p>
              <p className="text-4xl font-bold mt-1">{stats.pendingRequests}</p>
            </div>
            <Wrench className="w-10 h-10 text-amber-200" />
          </div>
          <p className="text-amber-200 text-sm mt-3">{stats.totalRequests} total requests</p>
        </div>

        <div className="bg-gradient-to-br from-purple-500 to-purple-600 rounded-2xl p-6 text-white">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-purple-100 text-sm font-medium">Available Rooms</p>
              <p className="text-4xl font-bold mt-1">{stats.availableRooms}</p>
            </div>
            <DoorOpen className="w-10 h-10 text-purple-200" />
          </div>
          <p className="text-purple-200 text-sm mt-3">{stats.maintenanceRooms} under maintenance</p>
        </div>
      </div>

      {/* Room Status Breakdown */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden">
          <div className="px-6 py-4 border-b border-slate-100 flex items-center justify-between">
            <h2 className="font-semibold text-slate-900">Room Status Overview</h2>
            <button
              onClick={() => generateCSV(rooms, 'rooms_report')}
              className="flex items-center gap-2 px-3 py-1.5 text-sm text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
            >
              <Download className="w-4 h-4" />
              Export CSV
            </button>
          </div>
          <div className="p-6">
            <div className="grid grid-cols-3 gap-4 mb-6">
              <div className="text-center p-4 bg-blue-50 rounded-xl">
                <div className="text-2xl font-bold text-blue-600">{stats.occupiedRooms}</div>
                <div className="text-sm text-slate-600">Occupied</div>
              </div>
              <div className="text-center p-4 bg-emerald-50 rounded-xl">
                <div className="text-2xl font-bold text-emerald-600">{stats.availableRooms}</div>
                <div className="text-sm text-slate-600">Available</div>
              </div>
              <div className="text-center p-4 bg-amber-50 rounded-xl">
                <div className="text-2xl font-bold text-amber-600">{stats.maintenanceRooms}</div>
                <div className="text-sm text-slate-600">Maintenance</div>
              </div>
            </div>

            {/* Visual Bar */}
            <div className="h-4 rounded-full bg-slate-100 overflow-hidden flex">
              <div
                className="bg-blue-500 h-full"
                style={{ width: `${stats.totalRooms > 0 ? (stats.occupiedRooms / stats.totalRooms) * 100 : 0}%` }}
              />
              <div
                className="bg-emerald-500 h-full"
                style={{ width: `${stats.totalRooms > 0 ? (stats.availableRooms / stats.totalRooms) * 100 : 0}%` }}
              />
              <div
                className="bg-amber-500 h-full"
                style={{ width: `${stats.totalRooms > 0 ? (stats.maintenanceRooms / stats.totalRooms) * 100 : 0}%` }}
              />
            </div>
            <div className="flex justify-center gap-6 mt-3 text-sm">
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full bg-blue-500" />
                <span className="text-slate-600">Occupied</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full bg-emerald-500" />
                <span className="text-slate-600">Available</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full bg-amber-500" />
                <span className="text-slate-600">Maintenance</span>
              </div>
            </div>
          </div>
        </div>

        {/* Maintenance Summary */}
        <div className="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden">
          <div className="px-6 py-4 border-b border-slate-100 flex items-center justify-between">
            <h2 className="font-semibold text-slate-900">Maintenance Summary</h2>
            <button
              onClick={() => generateCSV(requests, 'maintenance_report')}
              className="flex items-center gap-2 px-3 py-1.5 text-sm text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
            >
              <Download className="w-4 h-4" />
              Export CSV
            </button>
          </div>
          <div className="p-6">
            {/* Status breakdown */}
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-3 h-3 rounded-full bg-amber-500" />
                  <span className="text-slate-700">Pending</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-32 h-2 bg-slate-100 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-amber-500 rounded-full"
                      style={{ width: `${stats.totalRequests > 0 ? (stats.pendingRequests / stats.totalRequests) * 100 : 0}%` }}
                    />
                  </div>
                  <span className="text-slate-900 font-semibold w-8 text-right">{stats.pendingRequests}</span>
                </div>
              </div>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-3 h-3 rounded-full bg-blue-500" />
                  <span className="text-slate-700">In Progress</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-32 h-2 bg-slate-100 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-blue-500 rounded-full"
                      style={{ width: `${stats.totalRequests > 0 ? ((stats.totalRequests - stats.pendingRequests - stats.resolvedRequests) / stats.totalRequests) * 100 : 0}%` }}
                    />
                  </div>
                  <span className="text-slate-900 font-semibold w-8 text-right">{stats.totalRequests - stats.pendingRequests - stats.resolvedRequests}</span>
                </div>
              </div>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-3 h-3 rounded-full bg-emerald-500" />
                  <span className="text-slate-700">Resolved</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-32 h-2 bg-slate-100 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-emerald-500 rounded-full"
                      style={{ width: `${stats.totalRequests > 0 ? (stats.resolvedRequests / stats.totalRequests) * 100 : 0}%` }}
                    />
                  </div>
                  <span className="text-slate-900 font-semibold w-8 text-right">{stats.resolvedRequests}</span>
                </div>
              </div>
            </div>

            <div className="mt-6 pt-6 border-t border-slate-100">
              <div className="flex items-center justify-between">
                <span className="text-slate-600">Resolution Rate</span>
                <span className="text-2xl font-bold text-slate-900">
                  {stats.totalRequests > 0 ? Math.round((stats.resolvedRequests / stats.totalRequests) * 100) : 0}%
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Tenant Report */}
      <div className="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden">
        <div className="px-6 py-4 border-b border-slate-100 flex items-center justify-between">
          <h2 className="font-semibold text-slate-900">Tenant Report</h2>
          <button
            onClick={() => generateCSV(tenants.map(t => ({
              name: `${t.first_name} ${t.last_name}`,
              email: t.email || 'N/A',
              phone: t.phone || 'N/A',
              status: t.status,
              move_in_date: t.move_in_date || 'N/A'
            })), 'tenants_report')}
            className="flex items-center gap-2 px-3 py-1.5 text-sm text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
          >
            <Download className="w-4 h-4" />
            Export CSV
          </button>
        </div>
        <div className="p-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="p-4 bg-slate-50 rounded-xl text-center">
              <FileBarChart className="w-8 h-8 mx-auto mb-2 text-slate-400" />
              <p className="text-2xl font-bold text-slate-900">{stats.totalTenants}</p>
              <p className="text-sm text-slate-600">Total Tenants</p>
            </div>
            <div className="p-4 bg-emerald-50 rounded-xl text-center">
              <Users className="w-8 h-8 mx-auto mb-2 text-emerald-500" />
              <p className="text-2xl font-bold text-emerald-600">{stats.activeTenants}</p>
              <p className="text-sm text-slate-600">Active</p>
            </div>
            <div className="p-4 bg-slate-50 rounded-xl text-center">
              <Users className="w-8 h-8 mx-auto mb-2 text-slate-400" />
              <p className="text-2xl font-bold text-slate-500">{stats.totalTenants - stats.activeTenants}</p>
              <p className="text-sm text-slate-600">Inactive</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
