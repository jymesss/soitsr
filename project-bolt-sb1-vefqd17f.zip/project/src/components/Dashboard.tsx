import { useEffect, useState } from 'react';
import { supabase, Room, Tenant, MaintenanceRequest } from '../lib/supabase';
import { DoorOpen, Users, Wrench, AlertCircle, TrendingUp, Clock } from 'lucide-react';

type StatCardProps = {
  icon: typeof DoorOpen;
  label: string;
  value: number | string;
  sublabel: string;
  color: 'blue' | 'green' | 'amber' | 'purple';
};

function StatCard({ icon: Icon, label, value, sublabel, color }: StatCardProps) {
  const colors = {
    blue: 'from-blue-500 to-blue-600 shadow-blue-500/30',
    green: 'from-emerald-500 to-emerald-600 shadow-emerald-500/30',
    amber: 'from-amber-500 to-amber-600 shadow-amber-500/30',
    purple: 'from-purple-500 to-purple-600 shadow-purple-500/30',
  };

  return (
    <div className="bg-white rounded-2xl p-6 shadow-sm border border-slate-100">
      <div className="flex items-start justify-between">
        <div>
          <p className="text-sm font-medium text-slate-500">{label}</p>
          <p className="text-3xl font-bold text-slate-900 mt-1">{value}</p>
          <p className="text-sm text-slate-400 mt-1">{sublabel}</p>
        </div>
        <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${colors[color]} flex items-center justify-center shadow-lg`}>
          <Icon className="w-6 h-6 text-white" />
        </div>
      </div>
    </div>
  );
}

export function Dashboard() {
  const [stats, setStats] = useState({
    totalRooms: 0,
    occupied: 0,
    available: 0,
    maintenance: 0,
    totalTenants: 0,
    openTickets: 0,
    resolvedTickets: 0,
  });
  const [recentTickets, setRecentTickets] = useState<(MaintenanceRequest & { room: Room })[]>([]);
  const [rooms, setRooms] = useState<Room[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function fetchData() {
      const [roomsRes, tenantsRes, ticketsRes] = await Promise.all([
        supabase.from('rooms').select('*'),
        supabase.from('tenants').select('*').eq('status', 'active'),
        supabase.from('maintenance_requests').select('*, room:rooms(*)').order('created_at', { ascending: false }).limit(5),
      ]);

      const roomsData = roomsRes.data || [];
      const tenantsData = tenantsRes.data || [];
      const ticketsData = ticketsRes.data || [];

      setRooms(roomsData);
      setRecentTickets(ticketsData);
      setStats({
        totalRooms: roomsData.length,
        occupied: roomsData.filter((r) => r.status === 'occupied').length,
        available: roomsData.filter((r) => r.status === 'available').length,
        maintenance: roomsData.filter((r) => r.status === 'maintenance').length,
        totalTenants: tenantsData.length,
        openTickets: ticketsData.filter((t) => t.status !== 'resolved').length,
        resolvedTickets: ticketsData.filter((t) => t.status === 'resolved').length,
      });
      setLoading(false);
    }

    fetchData();
  }, []);

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <div className="w-8 h-8 border-4 border-blue-600 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-slate-900">Dashboard</h1>
        <p className="text-slate-500 mt-1">Overview of dormitory operations</p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard
          icon={DoorOpen}
          label="Total Rooms"
          value={stats.totalRooms}
          sublabel={`${stats.occupied} occupied, ${stats.available} available`}
          color="blue"
        />
        <StatCard
          icon={Users}
          label="Active Tenants"
          value={stats.totalTenants}
          sublabel="Currently living"
          color="green"
        />
        <StatCard
          icon={Wrench}
          label="Open Tickets"
          value={stats.openTickets}
          sublabel="Pending maintenance"
          color="amber"
        />
        <StatCard
          icon={TrendingUp}
          label="Resolved"
          value={stats.resolvedTickets}
          sublabel="Completed requests"
          color="purple"
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden">
          <div className="px-6 py-4 border-b border-slate-100">
            <h2 className="font-semibold text-slate-900">Room Status Overview</h2>
          </div>
          <div className="divide-y divide-slate-100">
            {rooms.map((room) => (
              <div key={room.id} className="px-6 py-3 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className={`w-10 h-10 rounded-lg flex items-center justify-center font-bold text-sm ${
                    room.status === 'available' ? 'bg-emerald-50 text-emerald-600' :
                    room.status === 'occupied' ? 'bg-blue-50 text-blue-600' :
                    'bg-amber-50 text-amber-600'
                  }`}>
                    {room.room_number}
                  </div>
                  <div>
                    <div className="font-medium text-slate-900">Room {room.room_number}</div>
                    <div className="text-sm text-slate-500">Floor {room.floor}</div>
                  </div>
                </div>
                <span className={`px-3 py-1 rounded-full text-sm font-medium capitalize ${
                  room.status === 'available' ? 'bg-emerald-100 text-emerald-700' :
                  room.status === 'occupied' ? 'bg-blue-100 text-blue-700' :
                  'bg-amber-100 text-amber-700'
                }`}>
                  {room.status}
                </span>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden">
          <div className="px-6 py-4 border-b border-slate-100">
            <h2 className="font-semibold text-slate-900">Recent Maintenance Tickets</h2>
          </div>
          {recentTickets.length === 0 ? (
            <div className="px-6 py-8 text-center text-slate-500">
              <AlertCircle className="w-10 h-10 mx-auto mb-2 text-slate-300" />
              <p>No maintenance requests yet</p>
            </div>
          ) : (
            <div className="divide-y divide-slate-100">
              {recentTickets.map((ticket) => (
                <div key={ticket.id} className="px-6 py-3 flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${
                      ticket.status === 'pending' ? 'bg-amber-50' :
                      ticket.status === 'in_progress' ? 'bg-blue-50' :
                      'bg-emerald-50'
                    }`}>
                      <Wrench className={`w-5 h-5 ${
                        ticket.status === 'pending' ? 'text-amber-500' :
                        ticket.status === 'in_progress' ? 'text-blue-500' :
                        'text-emerald-500'
                      }`} />
                    </div>
                    <div>
                      <div className="font-medium text-slate-900">Room {ticket.room?.room_number}</div>
                      <div className="text-sm text-slate-500 line-clamp-1">{ticket.issue_description}</div>
                    </div>
                  </div>
                  <span className={`px-3 py-1 rounded-full text-sm font-medium ${
                    ticket.status === 'pending' ? 'bg-amber-100 text-amber-700' :
                    ticket.status === 'in_progress' ? 'bg-blue-100 text-blue-700' :
                    'bg-emerald-100 text-emerald-700'
                  }`}>
                    {ticket.status.replace('_', ' ')}
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
