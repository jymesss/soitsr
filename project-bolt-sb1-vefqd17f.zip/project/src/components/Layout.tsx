import { useState } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { LayoutDashboard, DoorOpen, Users, Wrench, FileBarChart, LogOut, Menu, X, Home, Shield, User } from 'lucide-react';
import { ReactNode } from 'react';

type LayoutProps = {
  children: ReactNode;
  activeSection: string;
  onNavigate: (section: string) => void;
};

export function Layout({ children, activeSection, onNavigate }: LayoutProps) {
  const { profile, isAdmin, signOut } = useAuth();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const adminNavItems = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'rooms', label: 'Room Management', icon: DoorOpen },
    { id: 'tenants', label: 'Tenant Records', icon: Users },
    { id: 'maintenance', label: 'Maintenance', icon: Wrench },
    { id: 'reports', label: 'Reports', icon: FileBarChart },
  ];

  const tenantNavItems = [
    { id: 'rooms', label: 'Available Rooms', icon: DoorOpen },
    { id: 'maintenance', label: 'My Requests', icon: Wrench },
  ];

  const navigation = isAdmin ? adminNavItems : tenantNavItems;

  return (
    <div className="min-h-screen bg-slate-50">
      <nav className="fixed top-0 left-0 right-0 z-50 bg-white/95 backdrop-blur-lg border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            {/* Logo */}
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-blue-600 to-cyan-500 flex items-center justify-center shadow-lg shadow-blue-500/20">
                <Home className="w-5 h-5 text-white" />
              </div>
              <div>
                <span className="text-xl font-bold text-slate-900">
                  SOIT<span className="text-blue-600">SR</span>
                </span>
              </div>
            </div>

            {/* Desktop Navigation */}
            <div className="hidden md:flex items-center gap-1">
              {navigation.map((item) => {
                const Icon = item.icon;
                const isActive = activeSection === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => onNavigate(item.id)}
                    className={`flex items-center gap-2 px-4 py-2 rounded-xl font-medium transition-all ${
                      isActive
                        ? 'bg-blue-600 text-white shadow-lg shadow-blue-500/30'
                        : 'text-slate-600 hover:bg-slate-100'
                    }`}
                  >
                    <Icon className="w-4 h-4" />
                    {item.label}
                  </button>
                );
              })}
            </div>

            {/* User Info & Sign Out */}
            <div className="flex items-center gap-3">
              <div className="hidden sm:flex items-center gap-2 px-3 py-1.5 rounded-xl border border-slate-200">
                {isAdmin ? (
                  <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-blue-600 to-cyan-500 flex items-center justify-center">
                    <Shield className="w-4 h-4 text-white" />
                  </div>
                ) : (
                  <div className="w-8 h-8 rounded-lg bg-slate-200 flex items-center justify-center">
                    <User className="w-4 h-4 text-slate-600" />
                  </div>
                )}
                <div className="text-sm">
                  <div className="font-medium text-slate-900">{profile?.full_name}</div>
                  <div className={`text-xs font-semibold ${isAdmin ? 'text-blue-600' : 'text-slate-500'}`}>
                    {isAdmin ? 'Admin' : 'Tenant'}
                  </div>
                </div>
              </div>
              <button
                onClick={signOut}
                className="flex items-center gap-2 px-3 py-2 text-slate-600 hover:text-red-600 hover:bg-red-50 rounded-xl transition-all"
              >
                <LogOut className="w-4 h-4" />
                <span className="hidden sm:inline">Sign Out</span>
              </button>
            </div>

            {/* Mobile Menu Button */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="md:hidden p-2 rounded-lg hover:bg-slate-100"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>

        {/* Mobile Navigation */}
        {mobileMenuOpen && (
          <div className="md:hidden border-t border-slate-200 bg-white">
            <div className="px-4 py-2 space-y-1">
              {navigation.map((item) => {
                const Icon = item.icon;
                const isActive = activeSection === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => {
                      onNavigate(item.id);
                      setMobileMenuOpen(false);
                    }}
                    className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl font-medium transition-all ${
                      isActive
                        ? 'bg-blue-600 text-white'
                        : 'text-slate-600 hover:bg-slate-100'
                    }`}
                  >
                    <Icon className="w-5 h-5" />
                    {item.label}
                  </button>
                );
              })}
            </div>
          </div>
        )}
      </nav>

      {/* Role Badge Banner */}
      <div className={`pt-16 ${isAdmin ? 'bg-gradient-to-r from-blue-600 to-cyan-500' : 'bg-slate-200'}`}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3">
          <div className="flex items-center gap-2">
            {isAdmin ? (
              <>
                <Shield className="w-5 h-5 text-white" />
                <span className="text-white font-medium">Admin Mode - Full Access to All Features</span>
              </>
            ) : (
              <>
                <User className="w-5 h-5 text-slate-600" />
                <span className="text-slate-600 font-medium">Tenant Mode - View Available Rooms & Submit Requests</span>
              </>
            )}
          </div>
        </div>
      </div>

      <main className="pb-8 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
        {children}
      </main>
    </div>
  );
}
