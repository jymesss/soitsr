import { useEffect, useState } from 'react';
import { supabase, Room } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import { Plus, Edit2, Trash2, DoorOpen, X, Eye, Shield } from 'lucide-react';

export function Rooms() {
  const { isAdmin } = useAuth();
  const [rooms, setRooms] = useState<Room[]>([]);
  const [loading, setLoading] = useState(true);
  const [modalOpen, setModalOpen] = useState(false);
  const [editingRoom, setEditingRoom] = useState<Room | null>(null);
  const [viewingRoom, setViewingRoom] = useState<Room | null>(null);
  const [formData, setFormData] = useState({
    room_number: '',
    floor: 1,
    capacity: 2,
    status: 'available' as 'available' | 'occupied' | 'maintenance',
  });

  useEffect(() => {
    fetchRooms();
  }, [isAdmin]);

  async function fetchRooms() {
    let query = supabase.from('rooms').select('*').order('room_number');

    // Tenants only see available rooms
    if (!isAdmin) {
      query = query.eq('status', 'available');
    }

    const { data } = await query;
    setRooms(data || []);
    setLoading(false);
  }

  function openModal(room?: Room) {
    if (!isAdmin) return;
    if (room) {
      setEditingRoom(room);
      setFormData({
        room_number: room.room_number,
        floor: room.floor,
        capacity: room.capacity,
        status: room.status,
      });
    } else {
      setEditingRoom(null);
      setFormData({ room_number: '', floor: 1, capacity: 2, status: 'available' });
    }
    setModalOpen(true);
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (editingRoom) {
      await supabase
        .from('rooms')
        .update(formData)
        .eq('id', editingRoom.id);
    } else {
      await supabase.from('rooms').insert(formData);
    }
    setModalOpen(false);
    fetchRooms();
  }

  async function deleteRoom(id: string) {
    if (!isAdmin) return;
    if (!confirm('Are you sure you want to delete this room?')) return;
    await supabase.from('rooms').delete().eq('id', id);
    fetchRooms();
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <div className="w-8 h-8 border-4 border-blue-600 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">
            {isAdmin ? 'Room Management' : 'Available Rooms'}
          </h1>
          <p className="text-slate-500 mt-1">
            {isAdmin
              ? 'Manage all dormitory rooms - Add, Edit, Delete rooms'
              : 'View rooms that are currently available for booking'}
          </p>
        </div>
        {isAdmin && (
          <button
            onClick={() => openModal()}
            className="flex items-center gap-2 px-5 py-2.5 bg-blue-600 text-white rounded-xl font-semibold hover:bg-blue-700 transition-colors shadow-lg shadow-blue-500/20"
          >
            <Plus className="w-5 h-5" />
            Add Room
          </button>
        )}
      </div>

      {/* Admin Only Banner */}
      {isAdmin && (
        <div className="bg-blue-50 border border-blue-200 rounded-xl p-4 flex items-center gap-3">
          <Shield className="w-6 h-6 text-blue-600" />
          <div>
            <p className="font-semibold text-blue-900">Admin Access</p>
            <p className="text-sm text-blue-700">You can add, edit, and delete rooms. Changes will affect tenant visibility.</p>
          </div>
        </div>
      )}

      {/* Tenant Info Banner */}
      {!isAdmin && (
        <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-4 flex items-center gap-3">
          <DoorOpen className="w-6 h-6 text-emerald-600" />
          <div>
            <p className="font-semibold text-emerald-900">Available Rooms</p>
            <p className="text-sm text-emerald-700">These rooms are ready for occupancy. Contact admin for room assignment.</p>
          </div>
        </div>
      )}

      {rooms.length === 0 ? (
        <div className="bg-white rounded-2xl shadow-sm border border-slate-100 p-12 text-center">
          <DoorOpen className="w-16 h-16 mx-auto mb-4 text-slate-300" />
          <p className="text-lg text-slate-500">
            {isAdmin ? 'No rooms added yet. Click "Add Room" to get started.' : 'No rooms available at the moment.'}
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {rooms.map((room) => (
            <div
              key={room.id}
              className="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden group hover:shadow-lg transition-shadow"
            >
              <div className={`h-3 ${
                room.status === 'available' ? 'bg-emerald-500' :
                room.status === 'occupied' ? 'bg-blue-500' :
                'bg-amber-500'
              }`} />
              <div className="p-6">
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-4">
                    <div className={`w-14 h-14 rounded-xl flex items-center justify-center ${
                      room.status === 'available' ? 'bg-emerald-50' :
                      room.status === 'occupied' ? 'bg-blue-50' :
                      'bg-amber-50'
                    }`}>
                      <DoorOpen className={`w-7 h-7 ${
                        room.status === 'available' ? 'text-emerald-600' :
                        room.status === 'occupied' ? 'text-blue-600' :
                        'text-amber-600'
                      }`} />
                    </div>
                    <div>
                      <h3 className="text-xl font-bold text-slate-900">Room {room.room_number}</h3>
                      <p className="text-sm text-slate-500">Floor {room.floor}</p>
                    </div>
                  </div>
                  {isAdmin && (
                    <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                      <button
                        onClick={() => openModal(room)}
                        className="p-2 text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
                        title="Edit Room"
                      >
                        <Edit2 className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => deleteRoom(room.id)}
                        className="p-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                        title="Delete Room"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  )}
                </div>

                <div className="mt-6 space-y-3">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-slate-500">Capacity</span>
                    <span className="font-semibold text-slate-900">{room.capacity} {room.capacity === 1 ? 'person' : 'persons'}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-slate-500">Status</span>
                    <span className={`px-3 py-1 rounded-full text-sm font-semibold capitalize ${
                      room.status === 'available' ? 'bg-emerald-100 text-emerald-700' :
                      room.status === 'occupied' ? 'bg-blue-100 text-blue-700' :
                      'bg-amber-100 text-amber-700'
                    }`}>
                      {room.status}
                    </span>
                  </div>
                </div>

                {!isAdmin && room.status === 'available' && (
                  <div className="mt-4 pt-4 border-t border-slate-100">
                    <button
                      onClick={() => setViewingRoom(room)}
                      className="w-full flex items-center justify-center gap-2 py-2 bg-emerald-50 text-emerald-700 rounded-lg font-medium hover:bg-emerald-100 transition-colors"
                    >
                      <Eye className="w-4 h-4" />
                      View Details
                    </button>
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Room Detail Modal (Tenant View) */}
      {viewingRoom && !isAdmin && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm">
          <div className="w-full max-w-md bg-white rounded-2xl shadow-2xl overflow-hidden">
            <div className={`h-3 ${
              viewingRoom.status === 'available' ? 'bg-emerald-500' : 'bg-blue-500'
            }`} />
            <div className="p-6">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-xl font-bold text-slate-900">Room {viewingRoom.room_number}</h2>
                <button
                  onClick={() => setViewingRoom(null)}
                  className="p-2 text-slate-400 hover:text-slate-600 hover:bg-slate-100 rounded-lg transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="space-y-4">
                <div className="flex justify-between py-3 border-b border-slate-100">
                  <span className="text-slate-500">Floor</span>
                  <span className="font-semibold text-slate-900">{viewingRoom.floor}</span>
                </div>
                <div className="flex justify-between py-3 border-b border-slate-100">
                  <span className="text-slate-500">Capacity</span>
                  <span className="font-semibold text-slate-900">{viewingRoom.capacity} persons</span>
                </div>
                <div className="flex justify-between py-3 border-b border-slate-100">
                  <span className="text-slate-500">Status</span>
                  <span className="px-3 py-1 rounded-full text-sm font-semibold bg-emerald-100 text-emerald-700">
                    Available
                  </span>
                </div>
              </div>

              <div className="mt-6 p-4 bg-blue-50 rounded-xl">
                <p className="text-sm text-blue-700">
                  Interested in this room? Please contact the dormitory administrator or submit a maintenance request for any inquiries.
                </p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Admin Edit/Add Modal */}
      {modalOpen && isAdmin && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm">
          <div className="w-full max-w-md bg-white rounded-2xl shadow-2xl overflow-hidden">
            <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100">
              <h2 className="text-lg font-semibold text-slate-900">
                {editingRoom ? 'Edit Room' : 'Add New Room'}
              </h2>
              <button
                onClick={() => setModalOpen(false)}
                className="p-2 text-slate-400 hover:text-slate-600 hover:bg-slate-100 rounded-lg transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="p-6 space-y-4">
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1.5">
                  Room Number *
                </label>
                <input
                  type="text"
                  value={formData.room_number}
                  onChange={(e) => setFormData({ ...formData, room_number: e.target.value })}
                  required
                  className="w-full px-4 py-2.5 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
                  placeholder="e.g. 101"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1.5">
                    Floor
                  </label>
                  <input
                    type="number"
                    value={formData.floor}
                    onChange={(e) => setFormData({ ...formData, floor: parseInt(e.target.value) || 1 })}
                    required
                    min={1}
                    max={10}
                    className="w-full px-4 py-2.5 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1.5">
                    Capacity
                  </label>
                  <input
                    type="number"
                    value={formData.capacity}
                    onChange={(e) => setFormData({ ...formData, capacity: parseInt(e.target.value) || 1 })}
                    required
                    min={1}
                    max={10}
                    className="w-full px-4 py-2.5 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1.5">
                  Status
                </label>
                <select
                  value={formData.status}
                  onChange={(e) => setFormData({ ...formData, status: e.target.value as typeof formData.status })}
                  className="w-full px-4 py-2.5 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
                >
                  <option value="available">Available</option>
                  <option value="occupied">Occupied</option>
                  <option value="maintenance">Under Maintenance</option>
                </select>
              </div>

              <button
                type="submit"
                className="w-full py-3 bg-blue-600 text-white font-semibold rounded-xl hover:bg-blue-700 transition-colors shadow-lg shadow-blue-500/20"
              >
                {editingRoom ? 'Save Changes' : 'Add Room'}
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
