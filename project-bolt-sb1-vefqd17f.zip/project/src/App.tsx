import { useState, useEffect } from 'react';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import { AuthScreen } from './components/AuthScreen';
import { Layout } from './components/Layout';
import { Dashboard } from './components/Dashboard';
import { Rooms } from './components/Rooms';
import { Tenants } from './components/Tenants';
import { Maintenance } from './components/Maintenance';
import { Reports } from './components/Reports';

function AppContent() {
  const { loading, session, isAdmin } = useAuth();
  const [activeSection, setActiveSection] = useState<string>('');

  // Set default section based on role
  useEffect(() => {
    if (session && !activeSection) {
      setActiveSection(isAdmin ? 'dashboard' : 'rooms');
    }
  }, [session, isAdmin, activeSection]);

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-slate-100 flex items-center justify-center">
        <div className="text-center">
          <div className="w-12 h-12 border-4 border-blue-600 border-t-transparent rounded-full animate-spin mx-auto mb-4" />
          <p className="text-slate-500">Loading...</p>
        </div>
      </div>
    );
  }

  if (!session) {
    return <AuthScreen />;
  }

  const renderSection = () => {
    switch (activeSection) {
      case 'dashboard':
        return isAdmin ? <Dashboard /> : <Rooms />;
      case 'rooms':
        return <Rooms />;
      case 'tenants':
        return isAdmin ? <Tenants /> : <Rooms />;
      case 'maintenance':
        return <Maintenance />;
      case 'reports':
        return isAdmin ? <Reports /> : <Maintenance />;
      default:
        return isAdmin ? <Dashboard /> : <Rooms />;
    }
  };

  return (
    <Layout activeSection={activeSection} onNavigate={setActiveSection}>
      {renderSection()}
    </Layout>
  );
}

function App() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
}

export default App;
