import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseAnonKey) {
  throw new Error('Missing Supabase environment variables');
}

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

export type Profile = {
  id: string;
  email: string;
  full_name: string;
  role: 'admin' | 'tenant';
  created_at: string;
};

export type Room = {
  id: string;
  room_number: string;
  floor: number;
  capacity: number;
  status: 'available' | 'occupied' | 'maintenance';
  created_at: string;
};

export type Tenant = {
  id: string;
  first_name: string;
  last_name: string;
  email: string | null;
  phone: string | null;
  emergency_contact: string | null;
  room_id: string | null;
  move_in_date: string | null;
  status: 'active' | 'inactive';
  user_id: string | null;
  created_at: string;
  room?: Room;
};

export type MaintenanceRequest = {
  id: string;
  room_id: string;
  issue_description: string;
  status: 'pending' | 'in_progress' | 'resolved';
  reported_date: string;
  resolved_date: string | null;
  created_at: string;
  room?: Room;
};
